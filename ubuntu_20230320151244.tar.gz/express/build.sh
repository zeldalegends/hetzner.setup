#!/bin/bash

docker build . -t <your username>/node-web-app