#!/bin/bash

docker compose down --remove-orphans


